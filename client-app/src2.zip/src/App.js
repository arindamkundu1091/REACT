import React from "react";
import "./App.css";
import Stopwatch from "./components/Stopwatch/Stopwatch";

function App() {
  return (
    <>
      <Stopwatch/>
    </>
  );
}

export default App;
