# Product Card TO Code

A Pen created on CodePen.io. Original URL: [https://codepen.io/fatihtakey/pen/eyyWVr](https://codepen.io/fatihtakey/pen/eyyWVr).

Product design by - Shakibul Islam
Dribbble - https://dribbble.com/Shakib402